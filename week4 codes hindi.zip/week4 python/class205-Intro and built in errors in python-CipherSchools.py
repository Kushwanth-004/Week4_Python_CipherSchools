# chapter 17
# bilt in errors
# exception , how to handel them
# raise your own errors, debugging, etc etc

# SyntaxError

# def func:
    # pass

# name = 'harshit'*

# IndentationError
# def func():
    # print('hello')
#   print('world')

# NameError

# print(func())

# print(5+ 'harshit')

# IndexError
# l=[1,2,3]
# print(l[4])

# ValueError
# s = 'abc'
# print(int(s))

# AttributeError

# l=[1,2,3]
# l.push('12')

# KeyError
d={"name":'harshit'}
print(d['age'])